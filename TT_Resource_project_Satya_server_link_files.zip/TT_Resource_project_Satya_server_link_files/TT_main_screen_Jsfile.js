function empreg1(){
	
	if(document.getElementById("dropbtn1").onclick);
	

	document.getElementById("contents1").style.display = "block";
	document.getElementById("contents2").style.display = "none";
	document.getElementById("a").style.display = "block";
}

function empreg2() {
	
	if(document.getElementById("dropbtn2").onclick);
	
	document.getElementById("contents1").style.display = "none";
	document.getElementById("contents2").style.display = "block";
	document.getElementById("a").style.display = "none";
}
