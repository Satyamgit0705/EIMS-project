
function empreg1() {

	if(document.getElementById("dropbtn1").onclick);
	
	
	document.getElementById("contents1").style.display = "block";
	document.getElementById("contents2").style.display = "none";
	document.getElementById("contents3").style.display = "none";
	document.getElementById("contents4").style.display = "none";
	
	If(document.getElementById("contents1").style.display = "block");
	document.getElementById("contents1").style.textarea = "focus"
	
}
function empreg2(){
	
	if(document.getElementById("dropbtn2").onclick);
	
	document.getElementById("contents1").style.display = "none";
	document.getElementById("contents2").style.display = "block";
	document.getElementById("contents3").style.display = "none";
	document.getElementById("contents4").style.display = "none";
	
}

function empreg3(){
	if(document.getElementById("dropbtn3").onclick);
	
	document.getElementById("contents1").style.display = "none";
	document.getElementById("contents2").style.display = "none";
	document.getElementById("contents3").style.display = "block";
	document.getElementById("contents4").style.display = "none";
	
}
function empreg4() {
	
	if(document.getElementById("dropbtn4").onclick);
	
	document.getElementById("contents1").style.display = "none";
	document.getElementById("contents2").style.display = "none";
	document.getElementById("contents3").style.display = "none";
	document.getElementById("contents4").style.display = "block";
	
}

